<?php

namespace League\Tactician\Exception;

/**
 * Marker interface for all Tactician exceptions
 */
interface Exception
{
}
