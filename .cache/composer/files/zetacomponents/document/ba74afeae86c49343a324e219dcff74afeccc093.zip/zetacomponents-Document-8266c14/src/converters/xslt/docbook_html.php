<?php
/**
 * File containing the ezcDocumentDocbookToHtmlXsltConverter class.
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * @package Document
 * @version //autogen//
 * @license http://www.apache.org/licenses/LICENSE-2.0 Apache License, Version 2.0
 */

/**
 * Converter for Docbook documents to XHtml using an available XSLT.
 *
 * By default the converter will try to download and use the XSLT provided at
 * http://docbook.sourceforge.net/release/xsl/current/html/docbook.xsl. You may
 * want to download and use the files locally.
 *
 * @package Document
 * @version //autogen//
 */
class ezcDocumentDocbookToHtmlXsltConverter extends ezcDocumentXsltConverter
{
    /**
     * Construct new document converter.
     *
     * @param ezcDocumentDocbookToHtmlXsltConverterOptions $options
     */
    public function __construct( ?ezcDocumentDocbookToHtmlXsltConverterOptions $options = null )
    {
        parent::__construct(
            $options === null ?
                new ezcDocumentDocbookToHtmlXsltConverterOptions() :
                $options
        );
    }

    /**
     * Build document
     *
     * Build document of appropriate type from the DOMDocument, created by the
     * XSLT transformation.
     *
     * @param DOMDocument $document
     * @return ezcDocumentXmlBase
     */
    protected function buildDocument( DOMDocument $document )
    {
        $doc = new ezcDocumentXhtml();
        $doc->setDomDocument( $document );
        return $doc;
    }
}

?>
