<?php
class Objet{
// Objet is not a typo, Object is a reserved keywork in 7.2+
}
?>
