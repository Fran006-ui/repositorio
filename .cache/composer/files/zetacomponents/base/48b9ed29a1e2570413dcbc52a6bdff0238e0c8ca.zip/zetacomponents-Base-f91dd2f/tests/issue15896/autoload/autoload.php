<?php

return array(
    'ab' 				=> 'ab.php'
);

?>
