<?php
require 'tutorial_autoload.php';

ezcBaseFile::removeRecursive( '/dat/dev/ezcomponents/trash' );

?>
