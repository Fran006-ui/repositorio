<?php
class erMyClass2
{
    function toString()
    {
      echo "Class 'erMyClass2'\n";
    }
}
?>