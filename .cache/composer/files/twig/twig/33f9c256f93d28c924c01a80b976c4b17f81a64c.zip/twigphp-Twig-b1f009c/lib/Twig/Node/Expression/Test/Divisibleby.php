<?php

use Twig\Node\Expression\Test\DivisiblebyTest;

class_exists('Twig\Node\Expression\Test\DivisiblebyTest');

if (\false) {
    class Twig_Node_Expression_Test_Divisibleby extends DivisiblebyTest
    {
    }
}
