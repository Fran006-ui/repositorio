<?php

use Twig\TokenParser\BlockTokenParser;

class_exists('Twig\TokenParser\BlockTokenParser');

if (\false) {
    class Twig_TokenParser_Block extends BlockTokenParser
    {
    }
}
