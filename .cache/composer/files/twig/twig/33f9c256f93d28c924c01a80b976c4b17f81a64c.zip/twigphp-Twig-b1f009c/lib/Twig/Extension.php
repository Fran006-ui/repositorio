<?php

use Twig\Extension\AbstractExtension;

class_exists('Twig\Extension\AbstractExtension');

if (\false) {
    class Twig_Extension extends AbstractExtension
    {
    }
}
