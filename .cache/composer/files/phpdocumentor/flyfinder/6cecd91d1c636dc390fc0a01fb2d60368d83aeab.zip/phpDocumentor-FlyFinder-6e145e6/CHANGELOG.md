2020-02-07: Version unreleased

# FIXED
 - #25: `InPath(new Path("bar"))` unexpectedly satisfied by `"bartholomew/TODO.txt"` thanks to [Szczepan Hołyszewski]

[Szczepan Hołyszewski]: https://github.com/rulatir
