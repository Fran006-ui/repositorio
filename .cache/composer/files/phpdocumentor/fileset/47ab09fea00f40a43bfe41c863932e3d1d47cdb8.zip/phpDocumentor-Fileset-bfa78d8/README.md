Fileset [![Build Status](https://secure.travis-ci.org/phpDocumentor/Fileset.png)](http://travis-ci.org/phpDocumentor/Fileset)
=======

A fileset component that manages the collection of files using directories and filenames
