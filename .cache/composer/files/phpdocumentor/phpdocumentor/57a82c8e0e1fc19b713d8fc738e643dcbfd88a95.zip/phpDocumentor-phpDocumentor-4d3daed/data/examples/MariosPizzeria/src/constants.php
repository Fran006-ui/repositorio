<?php

namespace Marios;

const OVEN_TEMPERATURE = 9001;

// this declaration may seem like it is in the namespace, but it is not! It is global.
define('HIGHER_OVEN_TEMPERATURE', 9002);
