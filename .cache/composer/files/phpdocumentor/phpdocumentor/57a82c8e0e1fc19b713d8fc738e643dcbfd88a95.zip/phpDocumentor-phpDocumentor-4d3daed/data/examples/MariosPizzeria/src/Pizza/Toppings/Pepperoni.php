<?php

declare(strict_types=1);

namespace Marios\Pizza\Toppings;

use Marios\Pizza\Topping;

final class Pepperoni extends Topping
{
    public function publiclyAvailable()
    {

    }
}
