---
name: Template report 🚀
about: I have a issue or missing feature with a template
---

# Template issue/request

<!-- Please provide a clear description of what problem you are trying to solve and how would you want it to be solved. -->

<!-- If you have an issue with a template please add a screenshot of the issue you are facing -->
