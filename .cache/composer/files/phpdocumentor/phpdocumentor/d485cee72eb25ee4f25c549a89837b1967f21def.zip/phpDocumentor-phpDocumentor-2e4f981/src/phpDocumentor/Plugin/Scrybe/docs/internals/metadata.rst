Metadata
========

.. toctree::

   table_of_contents
   assets
   glossary
