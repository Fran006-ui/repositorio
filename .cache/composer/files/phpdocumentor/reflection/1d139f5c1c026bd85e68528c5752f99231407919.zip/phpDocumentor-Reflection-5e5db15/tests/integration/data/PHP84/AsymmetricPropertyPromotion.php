<?php

declare(strict_types=1);

class AsymmetricPropertyPromotion
{
    public function __construct(
        protected(set) Pizza $pizza,
    ) {}
}
