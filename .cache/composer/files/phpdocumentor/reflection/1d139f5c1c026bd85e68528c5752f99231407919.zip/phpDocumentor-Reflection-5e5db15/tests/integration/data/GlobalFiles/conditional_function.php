<?php
declare(strict_types=1);

if (!function_exists('h')) {
    function h() {

    }
} elseif(!function_exists('i')) {
    if (true) {
        function i()
        {
        }
    }
} else {
    function j() {

    }
}

function a() {

}
