GraphViz [![Build Status](https://secure.travis-ci.org/phpDocumentor/GraphViz.png)](http://travis-ci.org/phpDocumentor/GraphViz)
========

GraphViz is a library meant for generating .dot files for GraphViz with a
fluent interface.
