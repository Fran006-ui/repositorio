<?php
return array(
	'key' => 'value'
);
