This JSON parser was copied from https://github.com/BaseMax/JPOPHP for comparison against Parsica's JSON parser.
