#CHANGELOG

Please see the [release notes on GitHub](https://github.com/parsica-php/parsica/releases).
